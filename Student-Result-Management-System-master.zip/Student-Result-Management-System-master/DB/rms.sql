-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 14, 2020 at 10:27 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(10) NOT NULL,
  `username` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `password` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `AdminChngDate` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `adminChngDate`) VALUES
(1, 'admin', '1234', '2020-08-09 15:16:00');

-- --------------------------------------------------------
--
-- Table structure for table `hod`
--
CREATE TABLE `hod` (
  `id` int(10) NOT NULL,
  `hodname` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `password` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `hodChngDate` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hod`
--

INSERT INTO `hod` (`id`, `hodname`, `password`, `hodChngDate`) VALUES
(1, 'hod@cse', 'cse123', '2020-08-09 15:16:00'),
(2, 'hod@ece', 'ece123', '2020-08-09 15:16:00'),
(3, 'hod@eee', 'eee123', '2020-08-09 15:16:00');


--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `id` int(255) NOT NULL,
  `admissionno` varchar(10) NOT NULL,
  `name` varchar(20) NOT NULL,
   `branch` varchar(20) NOT NULL,
  `sem1` INT(3),
`sem2` INT(3),
`sem3` INT(3),
`sem4`  INT(3),
`sem5` INT,
`sem6` INT,
`sem7` INT,
`sem8` INT

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
--
-- Dumping data for table `result`
--

INSERT INTO `result` (`id`, `admissionno`, `name`, `branch`,`sem1`, `sem2`, `sem3`, `sem4`, `sem5`, `sem6`, `sem7`, `sem8`) VALUES
('1', '18001A0519', 'sujana','cse', '79', '85', '82', '0', '0', '0', '0', '0'),
('2', '18001A0729', 'gabi','mechanical', '89', '75', '89', '0', '0', '0', '0', '0'),
('3','18001A0711','Rio','mechanical','87','76','85','0','0','0','0','0'),
('4','18001A0712','Sam','mechanical','77','82','80','0','0','0','0','0');


-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `result`
--
ALTER TABLE `result`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admissionno` (`admissionno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `result`
--
ALTER TABLE `result`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
