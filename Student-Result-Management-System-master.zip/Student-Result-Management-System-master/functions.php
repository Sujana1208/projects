<?php
 $con=mysqli_connect("localhost","root","","rms");
 if($con)
 {
	$file=$_FILES['file']['tmp_name'] ;
	$handle=fopen($file,"r");
	$i=0;
	while(($cont=fgetcsv($handle,10000,","))!==false)
	{
		$table=rtrim($_FILES['file']['name'],".csv");
		if($i==0){
			
		$admissionno=$cont[0];
		$name=$cont[1];
		$branch=$cont[2];
		$status=$cont[3];
		$marks=$cont[4];
		$sub=$cont[5];
		
		$query="CREATE TABLE $table($admissionno VARCHAR(10),$name VARCHAR(50),$branch VARCHAR(20),$status INT(5),$marks INT(4),$sub VARCHAR(20));";
         echo "file is imported";
		 
		mysqli_query($con,$query);
		}
		else{
			
          $query="INSERT INTO $table($admissionno,$name,$branch,$status,$marks,$sub)VALUES('$cont[0]','$cont[1]','$cont[2]','$cont[3]','$cont[4]','$cont[5]');";	
	
		mysqli_query($con,$query);
	}
	$i++;
	
	}
	
 }
 else{
	 echo "connection failed";
 }
 
	 
 