<!DOCTYPE html>
<html>
<head>
    <title>AdminPanel</title>
    <link rel="stylesheet" type="text/css" href="css/leftbar.css">
</head>
<body>
<ul class="ul-verticle">
    <div class="li-verticle">
        <li><a href="enter-result.php">Enter Result</a></li>
        <li><a href="update-result.php">Update Result</a></li>
        <li><a href="view-result.php">View</a></li>
        <li><a href="delete-result.php">Delete</a></li>
        <li><a href="change-pass.php">Change Password</a></li>
       
    </div>
</ul>



</body>
</html>