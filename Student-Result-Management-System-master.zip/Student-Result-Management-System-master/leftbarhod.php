<!DOCTYPE html>
<html>
<head>
    <title>HodPanel</title>
    <link rel="stylesheet" type="text/css" href="css/leftbar.css">
</head>
<body>
<ul class="ul-verticle">
    <div class="li-verticle">
        <li><a href="viewcse-result.php">cse</a></li>
        <li><a href="viewece-result.php">ece</a></li>
		<li><a href="viewmech-result.php">mechanical</a></li>
		<li><a href="viewcivil-result.php">civil</a></li>
        
       
    </div>
</ul>



</body>
</html>