<?php
$con=mysqli_connect('localhost','root','','rms');
if (!$con) {
  die("Connection failed");
}
else{


	$sql="SELECT admissionno,name,branch FROM r WHERE branch='cse'";
			
	
	$res=mysqli_query($con,$sql);
	$num_rows=mysqli_num_rows($res);
	echo " 
    <table border='1' cellspacing='0'  width='90%'>
        <thead>
	        <tr>
	            
				
	            <th>Admissionno</th>
	            <th>name</th>
	            <th>branch</th>
	            
	            
	           
	        </tr>
        </thead>";

	if($num_rows>0)
	{
		while($row=mysqli_fetch_array($res))
		{
			echo'<tbody>';
				echo'<tr>';

					

					echo'<td>';
					echo $row['admissionno'];
					echo '</td>';

					echo'<td>';
					echo $row['name'];
					echo '</td>';

					

					echo'<td>';
					echo $row['branch'];
					echo '</td>';

					

					
				echo'</tr>';
			echo'</tbody>';
			echo'<br>';
		}
	}
	else
	{
		echo"NO DATA FOUND";
	}

}
?>
