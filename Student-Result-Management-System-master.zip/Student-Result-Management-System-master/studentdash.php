<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="css/studentdash.css">
	
	<title>Student Dashboard</title>
</head>
<body> <div  class="bgimg">

<div id="non-printable"><?php  include('topbar.php');?> </div>

<br><br><id='non-printable'hr>
<marquee id="non-printable" bgcolor="#CCCEDA" style="opacity: 0.6; color:red"; width="100%" direction="left" height="50px"><br>
Check your results.....
</marquee> <id='non-printable'hr>      

<center>
    <h1 id="non-printable">Student Result Management System</h1>
<div id="non-printable">
		<form action="#" method="POST">
		
        <table>
            <tr>
           	    <th>
                    <label>Hallticket No</label>
           	    </th>
           	    <td> 
           	        <input class="input-box" type="text" name="admissionno">
                </td>
            </tr>
            <tr>
                <th></th>
                <td></td>
            </tr>
            <tr>
                <th></th>
                <td></td>
            </tr>

            <tr>	   
               	<th>
           	        <label>Password</label>
           	    </th> 
           	    <td>
           	        <input class="input-box" type="text" name="name">
           	    </td>
            </tr>
            <tr>
                <th></th>
                <td></td>
            </tr>
            <tr>
                <th></th>
                <td></td>
            </tr>
            
                <th></th>
                <td></td>
            </tr><tr>
                <th></th>
                <td></td>
            </tr><tr>
                <th></th>
                <td></td>
            </tr><tr>
                <th></th>
                <td></td>
            </tr>
            <tr> 
                <th>
                    <button class="buton" type="submit" name="search" style="vertical-align:middle">
                        <span>Search </span>
                    </button>

                </th>
                <td> 
                    <button class="buton" type="reset" name="reset" style="vertical-align:middle">
                        <span>Reset </span>
                    </button>
                </td>
            </tr>
        </table>
    </form><br><br><br><br><br><br><br><br><br>
    

    <br><br><br><br><br><br><br><br><br><br><br>
</div> 
</center>

    
</body>
</html>
<?php

if(isset($_POST['search'])) {
    

    $con=mysqli_connect('localhost','root','','rms');
    if (!$con) {
      die("Connection failed");
    }
    else{
        $admissionno = $_POST['admissionno'];
        $name = $_POST['name'];//do md5 at last

        $sql = "SELECT admissionno,name FROM r ";
        $res = mysqli_query($con,$sql);
        $num_row = mysqli_num_rows($res);

        if($num_row > 0){
            while($row = mysqli_fetch_array($res)){

                //this is to check if either of the fields are vacaent
                if (empty($admissionno) || empty($name)) {
                    $msg = 'requierd';
            		if($msg == 'requierd') echo '<script>alert("please fill all the fields")</script>';
                    break;
                }   
                //this part is to chk if the pass and user name are correct
                else if($admissionno == $row["admissionno"] && $name == $row["name"]){
                    echo '<script>alert("Result Declared scroll down to see")</script>';
                    $msg = 'yes';
                    break;
                }
                // this part is to accept 
                else {
                    $msg = 'no';
                }
                            
            }
			if($msg == 'no') echo '<script>alert("Invalid Details")</script>';
        }
        else
            echo '<script>alert("Result Not Declared")</script>';
    }
    $sql1="SELECT* FROM r WHERE admissionno = '$admissionno' AND name = '$name'";
            
    
    $res=mysqli_query($con,$sql1);
    $num_rows=mysqli_num_rows($res);
    

    if($num_rows>0)
    {
        while($row=mysqli_fetch_array($res))
        {
            echo "<div id='printable' ><id='non-printable'hr>";
            echo "<br><br><center><h1>Student's Result</h1></center>";
            echo "<table cellspacing='0' class='box' align='center' border='0'>";
            
            echo "<tr>";
            echo "<td align='right' style='font-size:20px;'>Hallticket No.:</td>";
            echo "<td><td>";
            echo "<td style='font-size:20px;'>";
            echo $row['admissionno'];
            echo "</td>";
            echo "</tr>";
           
            echo "<tr>";
            echo "<td align='right' style='font-size:20px;'>Name:</td>";
            echo "<td><td>";
            echo "<td style='font-size:20px;'>";
            echo $row['name'];
            echo "</td>";
            echo "</tr>";
            
           
            

            echo "<tr>";
            echo "<td align='right' style='font-size:20px;'>branch:</td>";
            echo "<td><td>";
            echo "<td style='font-size:20px;'>";
            echo $row['branch'];
            echo "</td>";
            echo "</tr>";

            echo "<tr>";
            echo "<td align='right' style='font-size:20px;'>semister:</td>";
            echo "<td><td>";
            echo "<td style='font-size:20px;'>";
            echo $row['status'];
            echo "</td>";
            echo "</tr>";

            echo "<tr>";
            echo "<td align='right' style='font-size:20px;'>marks:</td>";
            echo "<td><td>";
            echo "<td style='font-size:20px;'>";
            echo $row['marks'];
            echo "</td>";
            echo "</tr>";

            echo "<tr>";
            echo "<td align='right' style='font-size:20px;'>subject</td>";
            echo "<td><td>";
            echo "<td style='font-size:20px;'>";
            echo $row['subject'];
            echo "</td>";
            echo "</tr>";

                      
        }
    }  

    if($msg == 'yes') echo "<br><br><center><button id='non-printable' class='button'  onclick='javascript:window.print();'><span>Print</span></button>";
        
		
            
}

?>






