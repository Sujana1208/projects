<!DOCTYPE html>
<html>
<head>
    <title>Update Result</title>
    <link rel="stylesheet" type="text/css" href="css/update-result.css">
</head>
<body>
    <div >
        <header>
            <?php include('topbaradmin.php');?>
        </header>
    </div>
    <div >
        <?php include('leftbar.php');?>
    </div>

<div style="margin-left:25%;padding:1px 16px;height:1000px;">
    <br><br><br><br>
    <div class="box">
        <?php include('updt-res-form.php'); ?>
    </div>
</div>


</body>
</html>
