<!DOCTYPE html>
<html>
<head>
	<title>update result</title>
<link rel="stylesheet" type="text/css" href="css/updt-res-form.css">
</head>
<body style="color: #B739FE">
	<div>
		 <form action="#" method="post" ><br>
            <h2> UPDATE FORM</h2>
            <br><br>
            <font color="#0303AC">
            	Hallticket No:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </font>
            <input class="input-box" type="VALUE" name="rollno" placeholder="ROLL NUMBER"><br>
            <button class="button" type="submit" name="Submit" style="vertical-align:middle; margin-top: 10px">
                <span>Submit </span>
            </button>
        </form>
	</div>
</body>
</html>
<?php

if (isset($_POST['update'])) {
	$con=mysqli_connect('localhost','root','','rms');
    if (!$con) {
       die("Connection failed");
    }
	$sql="SELECT * FROM result";
	$res=mysqli_query($con,$sql);

	$row = mysqli_fetch_array($res);
	//student details
	$uadmissionno = $_POST['cng-admno'];
	$uname = $_POST['cng-name'];
	$ubranch = $_POST['cng-branch'];
	$usem1 = $_POST['cng-sem1'];
	$usem2 = $_POST['cng-sem2'];
	$usem3 = $_POST['cng-sem3'];
	$usem6 = $_POST['cng-sem6'];
	$usem7 = $_POST['cng-sem7'];
	$usem8 = $_POST['cng-sem8'];
	


	$sqli = "UPDATE `result` SET `admissionno` = '$uadmissionno',`name` = '$uname', `branch`= '$ubranch', `sem1`='$usem1', `sem2`='$usem2',`sem3`='$usem3',`sem4`='$usem4',`sem5`='$usem5',`sem6`='$sem6',`sem7`='$usem7',`sem8`='$usem8' WHERE admissionno = $uadmissionno";

	$chk = mysqli_query($con , $sqli);
	if($chk)
		echo "<script>alert(DATA UPDATED)</script>";
	else
		echo "<script>alert(DATA UPDATE FAILED)</script>";
		
	
}
if (isset($_POST['Submit'])) {
    

    $con=mysqli_connect('localhost','root','','rms');
    if (!$con) {
       die("Connection failed");
    }
    else{
    	$admissionno =$_POST['admissionno'];

    	$sql = "SELECT * FROM result";
    	$res = mysqli_query($con,$sql);
		$num_rows=mysqli_num_rows($res);

		if($num_rows>0){
			while($row=mysqli_fetch_array($res)){
				if($admissionno == $row['admissionno']){

	$sql="SELECT * FROM result";

	$res=mysqli_query($con,$sql);
	$num_rows=mysqli_num_rows($res);

	while($row=mysqli_fetch_array($res))
	{
		if($admissionno	== $row['admissionno']){
			$admissionno = $row['admissionno'];
			$name = $row['name'];
			$branch = $row['branch'];
			$sem1 = $row['sem1'];
			$sem2 = $row['sem2'];
			$sem3 = $row['sem3'];
			$sem4 = $row['sem4'];
			$sem5 = $row['sem5'];
			$sem6 = $row['sem6'];
			$sem7 = $row['sem7'];
			$sem8 = $row['sem8'];
			
			
		}
	}
echo '
	<hr>
	<div >
		<br>
		<form action="#" method="POST" enctype="multipart/form-data">
		<table>		
			<th><br>
				<tr> STUDENTS DETAILS:--</tr>
				<br>
			</th>
			<th>
				<tr>admissionno</tr>&nbsp;&nbsp;&nbsp;&nbsp;
				<tr><input class="input-box" type="text" name="cng-admissionno" value='; echo $admissionno; echo'>
			</th>
			<br><br>
			<th>
				<tr>NAME</tr>&nbsp;&nbsp;&nbsp;&nbsp;
				<tr><input class="input-box" type="text" name="cng-name" value='; echo $name; echo'>
			</th>
			<br><br>
			<th>
				<tr>branch</tr>&nbsp;&nbsp;&nbsp;&nbsp;
				<tr><input class="input-box" type="text" name="cng-branch" value='; echo $branch; echo'>
			</th>
			<br><br>
			<th>
				<tr>sem1</tr>&nbsp;&nbsp;&nbsp;&nbsp;
				<tr><input class="input-box"  type="text" name="cng-sem1" value='; echo $sem1; echo'>
			</th>
			<br><br>
			<th>
				<tr>sem2</tr>&nbsp;&nbsp;&nbsp;&nbsp;
				<tr><input class="input-box"  type="text" name="cng-sem2" value='; echo $sem2; echo'>
			</th>
			<br><br>
			<th>
				<tr>sem3</tr>&nbsp;&nbsp;&nbsp;&nbsp;
				<tr><input class="input-box"  type="text" name="cng-sem3" value='; echo $sem3; echo'>
			</th>
			<br><br>
			<th>
				<tr>sem4</tr>&nbsp;&nbsp;&nbsp;&nbsp;
				<tr><input class="input-box"  type="text" name="cng-sem4" value='; echo $sem4; echo'>
			</th>
			<br><br>
			<th>
				<tr>sem5</tr>&nbsp;&nbsp;&nbsp;&nbsp;
				<tr><input class="input-box"  type="text" name="cng-sem5" value='; echo $sem5; echo'>
			</th>
			<br><br>
			<th>
				<tr>sem6</tr>&nbsp;&nbsp;&nbsp;&nbsp;
				<tr><input class="input-box"  type="text" name="cng-sem6" value='; echo $sem6; echo'>
			</th>
			<br><br>
			<th>
				<tr>sem7</tr>&nbsp;&nbsp;&nbsp;&nbsp;
				<tr><input class="input-box"  type="text" name="cng-sem7" value='; echo $sem7; echo'>
			</th>
			<br><br>
			<th>
				<tr>sem8</tr>&nbsp;&nbsp;&nbsp;&nbsp;
				<tr><input class="input-box"  type="text" name="cng-sem8" value='; echo $sem8; echo'>
			</th>
			
		
		</table>
		<div>
			<button class="button" type="submit" name="update" value="update" style="vertical-align:middle; margin-top: 10px">
                <span>UPDATE</span>
            </button>
		</div>
		</form>
	</div>
';

					$msg = "updated";
					break;
				}
				else{
					$msg= "ROLL NUMBER NOT FOUND!!";
				}
			}
			if($admissionno != $row['admissionno']) echo "$msg";
		}
    }
}
?>